module.exports = {
  content: [
    "./pages/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}"
  ],
  theme: {
    extend: {
      colors: {
        skybrand: {
          DEFAULT: '#0ea5e9',
          600: '#0ea5e9'
        }
      }
    },
  },
  plugins: [],
}
