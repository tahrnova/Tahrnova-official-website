import Link from 'next/link';
export default function Navbar(){ 
  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="/"><a className="flex items-center gap-3">
          <img src="/logo.png" alt="TahrNova" className="w-12 h-12 object-contain"/>
          <div>
            <div className="text-lg font-semibold">TahrNova</div>
            <div className="text-xs text-sky-500">DESIGN.DEVELOP.GROW</div>
          </div>
        </a></Link>
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
          <Link href="/"><a className="hover:text-sky-500">Home</a></Link>
          <Link href="/services"><a className="hover:text-sky-500">Services</a></Link>
          <Link href="/portfolio"><a className="hover:text-sky-500">Portfolio</a></Link>
          <Link href="/about"><a className="hover:text-sky-500">About Us</a></Link>
          <Link href="/careers"><a className="hover:text-sky-500">Careers</a></Link>
          <Link href="/contact"><a className="hover:text-sky-500">Contact</a></Link>
          <a href="https://calendly.com/tahrnovaoffical/new-meeting" target="_blank" rel="noreferrer" className="ml-4 px-4 py-2 bg-sky-500 text-white rounded-lg text-sm">Appointment</a>
        </nav>
        <div className="md:hidden">
          <a href="/contact" className="px-3 py-2 bg-sky-500 text-white rounded-md text-sm">Contact</a>
        </div>
      </div>
    </header>
  )
}
