import { useState } from 'react';
export default function Careers(){
  const [form, setForm] = useState({name:'',email:'',phone:'',address:'',position:'',message:'',resume:null});
  function handle(e){
    const {name, value, files} = e.target;
    if(name==='resume') setForm(s=>({...s,resume:files[0]}));
    else setForm(s=>({...s,[name]:value}));
  }
  function submit(e){ e.preventDefault(); alert('Application submitted (front-end demo).'); setForm({name:'',email:'',phone:'',address:'',position:'',message:'',resume:null});}
  return (
    <main className="max-w-4xl mx-auto px-6 py-16">
      <h3 className="text-sky-500 font-semibold">Careers</h3>
      <h2 className="text-2xl font-bold mt-2">Join TahrNova</h2>
      <p className="text-gray-600 mt-2">Apply for open positions or send your CV for future consideration.</p>
      <form onSubmit={submit} className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <input name="name" value={form.name} onChange={handle} placeholder="Full name" className="p-3 border rounded" />
        <input name="email" value={form.email} onChange={handle} placeholder="Email" className="p-3 border rounded" />
        <input name="phone" value={form.phone} onChange={handle} placeholder="Phone" className="p-3 border rounded" />
        <input name="address" value={form.address} onChange={handle} placeholder="Address" className="p-3 border rounded" />
        <input name="position" value={form.position} onChange={handle} placeholder="Position applying for" className="p-3 border rounded md:col-span-2" />
        <textarea name="message" value={form.message} onChange={handle} placeholder="Short message / cover letter" className="p-3 border rounded md:col-span-2" />
        <div className="md:col-span-2 flex items-center gap-4">
          <label className="p-3 border rounded cursor-pointer">
            <input type="file" name="resume" onChange={handle} className="hidden" />
            Upload CV / Resume
          </label>
          <button type="submit" className="px-5 py-3 bg-sky-500 text-white rounded">Submit Application</button>
        </div>
      </form>
      <div className="mt-6 text-sm text-gray-600">Note: This form is front-end only. Connect to any backend or Form provider to collect submissions.</div>
    </main>
  )
}
