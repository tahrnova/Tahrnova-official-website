export default function Services(){
  const services = [
    'Digital Marketing','E-commerce','Healthcare AI & Automation','Data Analytics',
    'Graphic Design','UI & UX','App Development','Custom Software Development'
  ];
  return (
    <main className="max-w-6xl mx-auto px-6 py-16">
      <h3 className="text-sky-500 font-semibold">Our Services</h3>
      <h2 className="text-2xl font-bold mt-2">What we build</h2>
      <p className="text-gray-600 mt-2">Click any service to learn more.</p>
      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {services.map(s=>(
          <a key={s} href={"/services#"+s.replace(/\s+/g,'-')} className="block p-6 border rounded-lg hover:shadow">
            <div className="font-semibold">{s}</div>
          </a>
        ))}
      </div>
    </main>
  )
}
