import Link from 'next/link';
export default function Home(){
  return (
    <main className="max-w-6xl mx-auto px-6 py-16">
      <section className="grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">Empowering Companies with AI, Automation, and Digital Innovation</h1>
          <p className="mt-6 text-gray-700 max-w-xl">TahrNova builds intelligent systems and digital products that transform businesses — from AI-driven automation and software development to branding, digital marketing, and product design. We design. We develop. We grow.</p>
          <div className="mt-8 flex gap-4">
            <Link href="/contact"><a className="px-6 py-3 bg-sky-500 text-white rounded-lg font-medium">Get in touch</a></Link>
            <a href="https://calendly.com/tahrnovaoffical/new-meeting" target="_blank" rel="noreferrer" className="px-6 py-3 border border-sky-500 text-sky-500 rounded-lg font-medium">Schedule a Meeting</a>
          </div>
          <div className="mt-8 flex items-center gap-6 text-sm">
            <div>
              <div className="text-xs text-gray-500">Email</div>
              <a href="mailto:tahrnovaoffical@gmail.com" className="text-gray-800">tahrnovaoffical@gmail.com</a>
            </div>
            <div>
              <div className="text-xs text-gray-500">Phone</div>
              <a href="tel:03295521600" className="text-gray-800">03295521600</a>
            </div>
          </div>
          <div className="mt-8 flex gap-4 text-sm">
            <a href="https://www.linkedin.com/company/tahr-nova/?viewAsMember=true" target="_blank" rel="noreferrer" className="underline">LinkedIn</a>
            <a href="https://www.instagram.com/tahrnova/" target="_blank" rel="noreferrer" className="underline">Instagram</a>
            <a href="https://www.facebook.com/profile.php?viewas=100000686899395&id=61579036239665" target="_blank" rel="noreferrer" className="underline">Facebook</a>
            <a href="https://x.com/tahrnova" target="_blank" rel="noreferrer" className="underline">X (@tahrnova)</a>
          </div>
        </div>
        <div className="flex items-center justify-center">
          <img src="/logo.png" alt="TahrNova logo" className="w-80 h-80 object-contain" />
        </div>
      </section>

      <section id="mission" className="mt-20 bg-white rounded-xl p-8 border border-gray-100 shadow-sm">
        <div className="md:flex gap-8 items-center">
          <div className="md:w-1/2">
            <h3 className="text-sky-500 font-semibold">Our Mission</h3>
            <h2 className="text-2xl font-bold mt-2">Revolutionizing businesses through innovative software and AI.</h2>
            <p className="mt-4 text-gray-700">At TahrNova, our mission is to empower organizations of all sizes with intelligent digital solutions that unlock growth, improve operational efficiency, and deliver measurable value. We serve multiple industries—healthcare, e-commerce, education, fintech, and beyond—bringing tailored software, automation, design, and marketing expertise to every project.</p>
            <div className="mt-6 space-y-3">
              <p className="text-sm"><strong>Why choose TahrNova?</strong></p>
              <ul className="list-disc list-inside text-gray-700">
                <li>End-to-end product delivery: from design to deployment.</li>
                <li>AI-first approach — practical automation that saves time and money.</li>
                <li>Cross-industry experience: healthcare, e-commerce, education, and more.</li>
                <li>Transparent communication, timely delivery, and client-focused process.</li>
              </ul>
            </div>
            <div className="mt-6 text-sm text-gray-600">Founder: <span className="font-semibold">Tahreem Arshad</span></div>
          </div>

          <div className="md:w-1/2 mt-6 md:mt-0">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-6 border rounded-lg">
                <h4 className="font-semibold">Innovation</h4>
                <p className="text-sm text-gray-600 mt-2">Practical AI & custom software that solves real problems.</p>
              </div>
              <div className="p-6 border rounded-lg">
                <h4 className="font-semibold">Impact</h4>
                <p className="text-sm text-gray-600 mt-2">Solutions focused on measurable business outcomes.</p>
              </div>
              <div className="p-6 border rounded-lg">
                <h4 className="font-semibold">Growth</h4>
                <p className="text-sm text-gray-600 mt-2">Scaleable systems and marketing that drives growth.</p>
              </div>
              <div className="p-6 border rounded-lg">
                <h4 className="font-semibold">Trust</h4>
                <p className="text-sm text-gray-600 mt-2">Transparent process and long-term partnerships.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

    </main>
  )
}
