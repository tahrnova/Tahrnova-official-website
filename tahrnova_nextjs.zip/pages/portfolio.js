export default function Portfolio(){
  return (
    <main className="max-w-4xl mx-auto px-6 py-16">
      <h3 className="text-sky-500 font-semibold">Portfolio</h3>
      <h2 className="text-2xl font-bold mt-2">Selected Work</h2>
      <div className="mt-6 grid sm:grid-cols-2 gap-4">
        <a href="https://www.behance.net/gallery/235839269/e-commerce-custom-web" target="_blank" rel="noreferrer" className="p-6 border rounded-lg hover:shadow">
          <div className="font-semibold">E-commerce Custom Web</div>
          <div className="text-sm text-gray-600 mt-2">Behance case study</div>
        </a>
        <a href="https://github.com/tahrnova/Tahrnova-website-portfolio.git" target="_blank" rel="noreferrer" className="p-6 border rounded-lg hover:shadow">
          <div className="font-semibold">TahrNova Website Portfolio</div>
          <div className="text-sm text-gray-600 mt-2">GitHub repository</div>
        </a>
      </div>
    </main>
  )
}
