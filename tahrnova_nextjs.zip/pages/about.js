export default function About(){
  return (
    <main className="max-w-4xl mx-auto px-6 py-16">
      <div className="flex flex-col md:flex-row items-center gap-8">
        <div className="md:w-1/3">
          <img src="/logo.png" alt="logo" className="w-48 h-48 object-contain"/>
        </div>
        <div className="md:w-2/3">
          <h3 className="text-sky-500 font-semibold">About Us</h3>
          <h2 className="text-2xl font-bold mt-2">TahrNova — DESIGN.DEVELOP.GROW</h2>
          <p className="mt-4 text-gray-700">Founded by <strong>Tahreem Arshad</strong>, TahrNova is a full-service software and digital agency specializing in AI automation, custom applications, product design, and digital marketing. We work across industries—healthcare, e-commerce, education, fintech—and deliver measurable results for our clients.</p>
          <h4 className="mt-4 font-semibold">Why clients choose us</h4>
          <ul className="list-disc list-inside text-gray-700">
            <li>End-to-end delivery from concept to launch</li>
            <li>AI-first mindset and practical automation</li>
            <li>Strong UI/UX and branding expertise</li>
            <li>Transparent communication and client-focused process</li>
          </ul>
        </div>
      </div>
    </main>
  )
}
