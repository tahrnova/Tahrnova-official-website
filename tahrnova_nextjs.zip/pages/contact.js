export default function Contact(){
  return (
    <main className="max-w-4xl mx-auto px-6 py-16">
      <h3 className="text-sky-500 font-semibold">Contact</h3>
      <h2 className="text-2xl font-bold mt-2">Get in touch</h2>
      <div className="mt-6 grid md:grid-cols-2 gap-6">
        <div>
          <div className="text-sm text-gray-600">Email</div>
          <a href="mailto:tahrnovaoffical@gmail.com" className="block text-gray-800">tahrnovaoffical@gmail.com</a>
          <div className="mt-4 text-sm text-gray-600">Phone</div>
          <a href="tel:03295521600" className="block text-gray-800">03295521600</a>
          <div className="mt-4 text-sm text-gray-600">Appointment</div>
          <a href="https://calendly.com/tahrnovaoffical/new-meeting" target="_blank" rel="noreferrer" className="block text-sky-500">Schedule a meeting</a>
        </div>
        <div>
          <form className="space-y-3" onSubmit={(e)=>{e.preventDefault(); alert('Message sent (front-end demo).')}}>
            <input placeholder="Your name" className="w-full p-3 border rounded" />
            <input placeholder="Your email" className="w-full p-3 border rounded" />
            <textarea placeholder="Message" className="w-full p-3 border rounded" />
            <div className="flex gap-3">
              <button type="submit" className="px-4 py-2 bg-sky-500 text-white rounded">Send message</button>
              <a href="mailto:tahrnovaoffical@gmail.com" className="px-4 py-2 border rounded">Or email us</a>
            </div>
          </form>
        </div>
      </div>
    </main>
  )
}
